import React from 'react';
import { Calendar, Clock, User, ArrowRight, Tag, TrendingUp, BarChart3, PieChart, BookOpen } from 'lucide-react';

const Blog = () => {
  const blogPosts = [
    {
      title: "Advanced Statistical Analysis Techniques for Business Intelligence",
      excerpt: "Explore cutting-edge statistical methods that can transform your business data into actionable insights. Learn about regression analysis, hypothesis testing, and predictive modeling.",
      content: "In today's data-driven business environment, statistical analysis has become the cornerstone of informed decision-making...",
      author: "Muhammad Ayan",
      date: "December 15, 2023",
      readTime: "8 min read",
      category: "Statistical Analysis",
      tags: ["Statistics", "Business Intelligence", "Data Analysis"],
      image: "https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: true
    },
    {
      title: "Building Effective Data Visualization Dashboards",
      excerpt: "Master the art of creating compelling data visualizations that tell a story. Learn best practices for dashboard design, color theory, and user experience in analytics.",
      content: "Data visualization is more than just creating charts and graphs. It's about communicating complex information in a way that's both beautiful and functional...",
      author: "Muhammad Ayan",
      date: "December 10, 2023",
      readTime: "6 min read",
      category: "Data Visualization",
      tags: ["Tableau", "Power BI", "Dashboard Design"],
      image: "https://images.pexels.com/photos/669615/pexels-photo-669615.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: false
    },
    {
      title: "Predictive Analytics: From Theory to Implementation",
      excerpt: "Dive deep into predictive modeling techniques and learn how to implement machine learning algorithms for business forecasting and trend analysis.",
      content: "Predictive analytics represents the next frontier in business intelligence, enabling organizations to anticipate future trends and make proactive decisions...",
      author: "Muhammad Ayan",
      date: "December 5, 2023",
      readTime: "10 min read",
      category: "Predictive Analytics",
      tags: ["Machine Learning", "Forecasting", "Python"],
      image: "https://images.pexels.com/photos/186461/pexels-photo-186461.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: true
    },
    {
      title: "Customer Segmentation Strategies Using Data Analytics",
      excerpt: "Learn how to identify and analyze customer segments using advanced analytics techniques. Discover methods for improving customer retention and targeting.",
      content: "Customer segmentation is a powerful strategy that allows businesses to understand their diverse customer base and tailor their approaches accordingly...",
      author: "Muhammad Ayan",
      date: "November 28, 2023",
      readTime: "7 min read",
      category: "Customer Analytics",
      tags: ["Customer Analysis", "Segmentation", "Marketing"],
      image: "https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: false
    },
    {
      title: "Financial Risk Modeling with Advanced Analytics",
      excerpt: "Explore sophisticated risk assessment techniques used in financial analytics. Learn about portfolio optimization, stress testing, and regulatory compliance.",
      content: "Financial risk modeling has evolved significantly with the advent of advanced analytics and machine learning techniques...",
      author: "Muhammad Ayan",
      date: "November 20, 2023",
      readTime: "9 min read",
      category: "Financial Analytics",
      tags: ["Risk Management", "Finance", "Modeling"],
      image: "https://images.pexels.com/photos/159888/pexels-photo-159888.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: false
    },
    {
      title: "The Future of Business Intelligence: Trends and Innovations",
      excerpt: "Discover emerging trends in business intelligence and analytics. From AI-powered insights to real-time analytics, explore what's shaping the future of data.",
      content: "The landscape of business intelligence is rapidly evolving, driven by technological advances and changing business needs...",
      author: "Muhammad Ayan",
      date: "November 15, 2023",
      readTime: "5 min read",
      category: "Business Intelligence",
      tags: ["Future Trends", "AI", "Innovation"],
      image: "https://images.pexels.com/photos/373543/pexels-photo-373543.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: true
    }
  ];

  const categories = ["All", "Featured", "Statistical Analysis", "Data Visualization", "Predictive Analytics", "Customer Analytics", "Financial Analytics", "Business Intelligence"];
  const [selectedCategory, setSelectedCategory] = React.useState("All");

  const filteredPosts = selectedCategory === "All" 
    ? blogPosts 
    : selectedCategory === "Featured"
    ? blogPosts.filter(post => post.featured)
    : blogPosts.filter(post => post.category === selectedCategory);

  const readPost = (post: any) => {
    alert(`Reading: ${post.title}\n\n${post.content}\n\nThis would normally open the full blog post page.`);
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Statistical Analysis":
        return <BarChart3 className="w-4 h-4" />;
      case "Data Visualization":
        return <PieChart className="w-4 h-4" />;
      case "Predictive Analytics":
        return <TrendingUp className="w-4 h-4" />;
      default:
        return <BookOpen className="w-4 h-4" />;
    }
  };

  return (
    <div className="pt-20 min-h-screen bg-gradient-to-b from-black to-gray-950 relative">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.01)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.01)_1px,transparent_1px)] bg-[size:100px_100px]"></div>
      
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-24 relative z-10">
        <div className="text-center mb-20">
          <div className="inline-block px-4 py-2 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-full border border-blue-500/20 mb-6">
            <span className="text-blue-400 text-sm font-medium tracking-wider uppercase">Blog</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-8 tracking-tight">
            Analytics
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
              Insights
            </span>
          </h1>
          <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed mb-12">
            Explore the latest trends, techniques, and insights in data analytics and business intelligence
          </p>
          
          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-16">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-3 rounded-full font-medium transition-all duration-300 backdrop-blur-sm ${
                  selectedCategory === category
                    ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg shadow-blue-500/25 border border-blue-500/50'
                    : 'bg-gray-800/50 text-gray-300 hover:bg-gray-700/50 hover:text-white border border-gray-700/50 hover:border-gray-600/50'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Featured Posts */}
        {selectedCategory === "All" && (
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-white mb-8 text-center">Featured Articles</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {blogPosts.filter(post => post.featured).map((post, index) => (
                <article 
                  key={index}
                  className="group bg-gradient-to-br from-gray-900/50 to-gray-800/50 rounded-3xl overflow-hidden hover:from-gray-800/50 hover:to-gray-700/50 transition-all duration-500 transform hover:scale-105 border border-gray-700/50 hover:border-gray-600/50 backdrop-blur-sm relative"
                >
                  {/* Featured badge */}
                  <div className="absolute top-4 left-4 z-20 bg-gradient-to-r from-yellow-500 to-orange-500 text-black px-3 py-1 rounded-full text-xs font-bold">
                    FEATURED
                  </div>
                  
                  <div className="relative overflow-hidden">
                    <img 
                      src={post.image} 
                      alt={post.title}
                      className="w-full h-56 object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                    
                    {/* Category badge */}
                    <div className="absolute bottom-4 left-4 flex items-center space-x-2 bg-black/70 rounded-full px-4 py-2 backdrop-blur-sm">
                      {getCategoryIcon(post.category)}
                      <span className="text-white font-medium text-sm">{post.category}</span>
                    </div>
                  </div>
                  
                  <div className="p-8">
                    <div className="flex items-center space-x-4 mb-4 text-gray-400 text-sm">
                      <div className="flex items-center space-x-1">
                        <User className="w-4 h-4" />
                        <span>{post.author}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Calendar className="w-4 h-4" />
                        <span>{post.date}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>{post.readTime}</span>
                      </div>
                    </div>
                    
                    <h3 className="text-xl font-bold text-white mb-4 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-blue-400 group-hover:to-purple-400 transition-all duration-300">
                      {post.title}
                    </h3>
                    
                    <p className="text-gray-300 mb-6 leading-relaxed">{post.excerpt}</p>
                    
                    <div className="flex flex-wrap gap-2 mb-6">
                      {post.tags.map((tag, tagIndex) => (
                        <span 
                          key={tagIndex}
                          className="flex items-center space-x-1 px-3 py-1 bg-gray-800/50 text-gray-300 rounded-full text-sm font-medium border border-gray-700/50"
                        >
                          <Tag className="w-3 h-3" />
                          <span>{tag}</span>
                        </span>
                      ))}
                    </div>
                    
                    <button
                      onClick={() => readPost(post)}
                      className="flex items-center space-x-2 text-blue-400 hover:text-blue-300 transition-colors duration-200 font-medium group"
                    >
                      <span>Read Article</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </div>
        )}

        {/* All Posts */}
        <div>
          {selectedCategory !== "All" && (
            <h2 className="text-3xl font-bold text-white mb-8 text-center">
              {selectedCategory === "Featured" ? "Featured Articles" : selectedCategory}
            </h2>
          )}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post, index) => (
              <article 
                key={index}
                className="group bg-gradient-to-br from-gray-900/50 to-gray-800/50 rounded-3xl overflow-hidden hover:from-gray-800/50 hover:to-gray-700/50 transition-all duration-500 transform hover:scale-105 border border-gray-700/50 hover:border-gray-600/50 backdrop-blur-sm relative"
              >
                {/* Featured badge */}
                {post.featured && (
                  <div className="absolute top-4 left-4 z-20 bg-gradient-to-r from-yellow-500 to-orange-500 text-black px-3 py-1 rounded-full text-xs font-bold">
                    FEATURED
                  </div>
                )}
                
                <div className="relative overflow-hidden">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-56 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                  
                  {/* Category badge */}
                  <div className="absolute bottom-4 left-4 flex items-center space-x-2 bg-black/70 rounded-full px-4 py-2 backdrop-blur-sm">
                    {getCategoryIcon(post.category)}
                    <span className="text-white font-medium text-sm">{post.category}</span>
                  </div>
                </div>
                
                <div className="p-8">
                  <div className="flex items-center space-x-4 mb-4 text-gray-400 text-sm">
                    <div className="flex items-center space-x-1">
                      <User className="w-4 h-4" />
                      <span>{post.author}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Calendar className="w-4 h-4" />
                      <span>{post.date}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{post.readTime}</span>
                    </div>
                  </div>
                  
                  <h3 className="text-xl font-bold text-white mb-4 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-blue-400 group-hover:to-purple-400 transition-all duration-300">
                    {post.title}
                  </h3>
                  
                  <p className="text-gray-300 mb-6 leading-relaxed">{post.excerpt}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-6">
                    {post.tags.map((tag, tagIndex) => (
                      <span 
                        key={tagIndex}
                        className="flex items-center space-x-1 px-3 py-1 bg-gray-800/50 text-gray-300 rounded-full text-sm font-medium border border-gray-700/50"
                      >
                        <Tag className="w-3 h-3" />
                        <span>{tag}</span>
                      </span>
                    ))}
                  </div>
                  
                  <button
                    onClick={() => readPost(post)}
                    className="flex items-center space-x-2 text-blue-400 hover:text-blue-300 transition-colors duration-200 font-medium group"
                  >
                    <span>Read Article</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Blog;