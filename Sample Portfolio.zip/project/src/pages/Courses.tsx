import React from 'react';
import { Play, Clock, Users, Star, BookOpen, Award, Download, ExternalLink, Calendar, DollarSign } from 'lucide-react';

const Courses = () => {
  const courses = [
    {
      title: "Complete Data Analytics Masterclass",
      description: "Master the fundamentals of data analytics from data collection to advanced statistical analysis. Perfect for beginners and intermediate learners.",
      instructor: "Muhammad Ayan",
      duration: "12 hours",
      lessons: 45,
      students: 1250,
      rating: 4.9,
      reviews: 324,
      price: "$199",
      originalPrice: "$299",
      level: "Beginner to Intermediate",
      category: "Data Analytics",
      image: "https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: true,
      skills: ["Statistical Analysis", "Data Visualization", "Excel", "SQL Basics"],
      curriculum: [
        "Introduction to Data Analytics",
        "Data Collection and Cleaning",
        "Statistical Analysis Fundamentals",
        "Data Visualization Techniques",
        "Excel for Analytics",
        "SQL Basics for Data Analysis"
      ]
    },
    {
      title: "Advanced Statistical Analysis with R",
      description: "Deep dive into advanced statistical methods using R programming. Learn regression analysis, hypothesis testing, and predictive modeling.",
      instructor: "Muhammad Ayan",
      duration: "16 hours",
      lessons: 52,
      students: 890,
      rating: 4.8,
      reviews: 198,
      price: "$249",
      originalPrice: "$349",
      level: "Intermediate to Advanced",
      category: "Statistical Analysis",
      image: "https://images.pexels.com/photos/669615/pexels-photo-669615.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: false,
      skills: ["R Programming", "Statistical Modeling", "Regression Analysis", "Hypothesis Testing"],
      curriculum: [
        "R Programming Fundamentals",
        "Descriptive Statistics",
        "Inferential Statistics",
        "Regression Analysis",
        "ANOVA and Chi-Square Tests",
        "Advanced Statistical Modeling"
      ]
    },
    {
      title: "Business Intelligence with Tableau",
      description: "Create stunning dashboards and interactive visualizations using Tableau. Learn to tell compelling stories with your data.",
      instructor: "Muhammad Ayan",
      duration: "10 hours",
      lessons: 38,
      students: 1580,
      rating: 4.9,
      reviews: 445,
      price: "$179",
      originalPrice: "$249",
      level: "Beginner to Intermediate",
      category: "Data Visualization",
      image: "https://images.pexels.com/photos/186461/pexels-photo-186461.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: true,
      skills: ["Tableau", "Dashboard Design", "Data Storytelling", "Business Intelligence"],
      curriculum: [
        "Tableau Interface and Basics",
        "Data Connection and Preparation",
        "Creating Charts and Graphs",
        "Dashboard Design Principles",
        "Advanced Calculations",
        "Publishing and Sharing"
      ]
    },
    {
      title: "Predictive Analytics with Python",
      description: "Learn machine learning algorithms and predictive modeling techniques using Python. Build models that can forecast future trends.",
      instructor: "Muhammad Ayan",
      duration: "18 hours",
      lessons: 65,
      students: 720,
      rating: 4.7,
      reviews: 156,
      price: "$279",
      originalPrice: "$399",
      level: "Intermediate to Advanced",
      category: "Predictive Analytics",
      image: "https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: false,
      skills: ["Python", "Machine Learning", "Scikit-learn", "Pandas", "NumPy"],
      curriculum: [
        "Python for Data Science",
        "Data Preprocessing",
        "Supervised Learning Algorithms",
        "Unsupervised Learning",
        "Model Evaluation and Selection",
        "Deployment Strategies"
      ]
    },
    {
      title: "Financial Analytics and Risk Modeling",
      description: "Specialized course in financial data analysis, risk assessment, and portfolio optimization using advanced analytics techniques.",
      instructor: "Muhammad Ayan",
      duration: "14 hours",
      lessons: 48,
      students: 450,
      rating: 4.8,
      reviews: 89,
      price: "$299",
      originalPrice: "$449",
      level: "Advanced",
      category: "Financial Analytics",
      image: "https://images.pexels.com/photos/159888/pexels-photo-159888.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: true,
      skills: ["Financial Modeling", "Risk Analysis", "Portfolio Optimization", "VaR Calculation"],
      curriculum: [
        "Financial Data Sources",
        "Time Series Analysis",
        "Risk Metrics and KPIs",
        "Portfolio Theory",
        "Monte Carlo Simulation",
        "Regulatory Compliance"
      ]
    },
    {
      title: "Customer Analytics and Segmentation",
      description: "Learn to analyze customer behavior, create segments, and develop targeted marketing strategies using data analytics.",
      instructor: "Muhammad Ayan",
      duration: "8 hours",
      lessons: 32,
      students: 980,
      rating: 4.6,
      reviews: 234,
      price: "$149",
      originalPrice: "$199",
      level: "Beginner to Intermediate",
      category: "Customer Analytics",
      image: "https://images.pexels.com/photos/373543/pexels-photo-373543.jpeg?auto=compress&cs=tinysrgb&w=800",
      featured: false,
      skills: ["Customer Segmentation", "RFM Analysis", "Cohort Analysis", "CLV Calculation"],
      curriculum: [
        "Customer Data Understanding",
        "Segmentation Techniques",
        "RFM Analysis",
        "Cohort Analysis",
        "Customer Lifetime Value",
        "Marketing Analytics"
      ]
    }
  ];

  const categories = ["All", "Featured", "Data Analytics", "Statistical Analysis", "Data Visualization", "Predictive Analytics", "Financial Analytics", "Customer Analytics"];
  const [selectedCategory, setSelectedCategory] = React.useState("All");

  const filteredCourses = selectedCategory === "All" 
    ? courses 
    : selectedCategory === "Featured"
    ? courses.filter(course => course.featured)
    : courses.filter(course => course.category === selectedCategory);

  const enrollCourse = (course: any) => {
    alert(`Enrolling in: ${course.title}\n\nPrice: ${course.price}\n\nThis would normally redirect to the course enrollment page.`);
  };

  const previewCourse = (course: any) => {
    alert(`Course Preview: ${course.title}\n\nDuration: ${course.duration}\nLessons: ${course.lessons}\nLevel: ${course.level}\n\nCurriculum:\n${course.curriculum.join('\n')}\n\nThis would normally show a course preview.`);
  };

  const downloadSyllabus = (course: any) => {
    alert(`Downloading syllabus for: ${course.title}\n\nThis would normally download a PDF syllabus.`);
  };

  return (
    <div className="pt-20 min-h-screen bg-gradient-to-b from-black to-gray-950 relative">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.01)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.01)_1px,transparent_1px)] bg-[size:100px_100px]"></div>
      
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-24 relative z-10">
        <div className="text-center mb-20">
          <div className="inline-block px-4 py-2 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-full border border-blue-500/20 mb-6">
            <span className="text-blue-400 text-sm font-medium tracking-wider uppercase">Courses</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-8 tracking-tight">
            Analytics
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
              Courses
            </span>
          </h1>
          <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed mb-12">
            Master data analytics with comprehensive courses designed by industry experts. From beginner to advanced levels.
          </p>
          
          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-16">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-3 rounded-full font-medium transition-all duration-300 backdrop-blur-sm ${
                  selectedCategory === category
                    ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg shadow-blue-500/25 border border-blue-500/50'
                    : 'bg-gray-800/50 text-gray-300 hover:bg-gray-700/50 hover:text-white border border-gray-700/50 hover:border-gray-600/50'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Featured Courses */}
        {selectedCategory === "All" && (
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-white mb-8 text-center">Featured Courses</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {courses.filter(course => course.featured).map((course, index) => (
                <div 
                  key={index}
                  className="group bg-gradient-to-br from-gray-900/50 to-gray-800/50 rounded-3xl overflow-hidden hover:from-gray-800/50 hover:to-gray-700/50 transition-all duration-500 transform hover:scale-105 border border-gray-700/50 hover:border-gray-600/50 backdrop-blur-sm relative"
                >
                  {/* Featured badge */}
                  <div className="absolute top-4 left-4 z-20 bg-gradient-to-r from-yellow-500 to-orange-500 text-black px-3 py-1 rounded-full text-xs font-bold">
                    FEATURED
                  </div>
                  
                  {/* Discount badge */}
                  <div className="absolute top-4 right-4 z-20 bg-gradient-to-r from-green-500 to-emerald-500 text-white px-3 py-1 rounded-full text-xs font-bold">
                    33% OFF
                  </div>
                  
                  <div className="relative overflow-hidden">
                    <img 
                      src={course.image} 
                      alt={course.title}
                      className="w-full h-56 object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                    
                    {/* Play button overlay */}
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <button
                        onClick={() => previewCourse(course)}
                        className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm hover:bg-white/30 transition-colors duration-200"
                      >
                        <Play className="w-8 h-8 text-white ml-1" />
                      </button>
                    </div>
                    
                    {/* Course level badge */}
                    <div className="absolute bottom-4 left-4 bg-black/70 rounded-full px-4 py-2 backdrop-blur-sm">
                      <span className="text-white font-medium text-sm">{course.level}</span>
                    </div>
                  </div>
                  
                  <div className="p-8">
                    <div className="flex items-center justify-between mb-4">
                      <span className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded-full text-sm font-medium border border-blue-500/30">
                        {course.category}
                      </span>
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        <span className="text-white font-medium">{course.rating}</span>
                        <span className="text-gray-400 text-sm">({course.reviews})</span>
                      </div>
                    </div>
                    
                    <h3 className="text-xl font-bold text-white mb-4 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-blue-400 group-hover:to-purple-400 transition-all duration-300">
                      {course.title}
                    </h3>
                    
                    <p className="text-gray-300 mb-6 leading-relaxed">{course.description}</p>
                    
                    <div className="grid grid-cols-3 gap-4 mb-6 text-center">
                      <div className="flex flex-col items-center">
                        <Clock className="w-5 h-5 text-blue-400 mb-1" />
                        <span className="text-gray-300 text-sm">{course.duration}</span>
                      </div>
                      <div className="flex flex-col items-center">
                        <BookOpen className="w-5 h-5 text-purple-400 mb-1" />
                        <span className="text-gray-300 text-sm">{course.lessons} lessons</span>
                      </div>
                      <div className="flex flex-col items-center">
                        <Users className="w-5 h-5 text-green-400 mb-1" />
                        <span className="text-gray-300 text-sm">{course.students} students</span>
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-2 mb-6">
                      {course.skills.slice(0, 3).map((skill, skillIndex) => (
                        <span 
                          key={skillIndex}
                          className="px-3 py-1 bg-gray-800/50 text-gray-300 rounded-full text-sm font-medium border border-gray-700/50"
                        >
                          {skill}
                        </span>
                      ))}
                      {course.skills.length > 3 && (
                        <span className="px-3 py-1 bg-gray-800/50 text-gray-300 rounded-full text-sm font-medium border border-gray-700/50">
                          +{course.skills.length - 3} more
                        </span>
                      )}
                    </div>
                    
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center space-x-2">
                        <span className="text-2xl font-bold text-white">{course.price}</span>
                        <span className="text-gray-400 line-through">{course.originalPrice}</span>
                      </div>
                      <button
                        onClick={() => downloadSyllabus(course)}
                        className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors duration-200"
                      >
                        <Download className="w-4 h-4" />
                        <span className="text-sm">Syllabus</span>
                      </button>
                    </div>
                    
                    <div className="flex space-x-3">
                      <button
                        onClick={() => enrollCourse(course)}
                        className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl font-semibold hover:from-blue-600 hover:to-purple-600 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-blue-500/25"
                      >
                        Enroll Now
                      </button>
                      <button
                        onClick={() => previewCourse(course)}
                        className="px-6 py-3 border border-gray-600 text-gray-300 rounded-xl font-semibold hover:border-white hover:text-white transition-all duration-300 backdrop-blur-sm"
                      >
                        Preview
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* All Courses */}
        <div>
          {selectedCategory !== "All" && (
            <h2 className="text-3xl font-bold text-white mb-8 text-center">
              {selectedCategory === "Featured" ? "Featured Courses" : selectedCategory}
            </h2>
          )}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredCourses.map((course, index) => (
              <div 
                key={index}
                className="group bg-gradient-to-br from-gray-900/50 to-gray-800/50 rounded-3xl overflow-hidden hover:from-gray-800/50 hover:to-gray-700/50 transition-all duration-500 transform hover:scale-105 border border-gray-700/50 hover:border-gray-600/50 backdrop-blur-sm relative"
              >
                {/* Featured badge */}
                {course.featured && (
                  <div className="absolute top-4 left-4 z-20 bg-gradient-to-r from-yellow-500 to-orange-500 text-black px-3 py-1 rounded-full text-xs font-bold">
                    FEATURED
                  </div>
                )}
                
                {/* Discount badge */}
                <div className="absolute top-4 right-4 z-20 bg-gradient-to-r from-green-500 to-emerald-500 text-white px-3 py-1 rounded-full text-xs font-bold">
                  33% OFF
                </div>
                
                <div className="relative overflow-hidden">
                  <img 
                    src={course.image} 
                    alt={course.title}
                    className="w-full h-56 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                  
                  {/* Play button overlay */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <button
                      onClick={() => previewCourse(course)}
                      className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm hover:bg-white/30 transition-colors duration-200"
                    >
                      <Play className="w-8 h-8 text-white ml-1" />
                    </button>
                  </div>
                  
                  {/* Course level badge */}
                  <div className="absolute bottom-4 left-4 bg-black/70 rounded-full px-4 py-2 backdrop-blur-sm">
                    <span className="text-white font-medium text-sm">{course.level}</span>
                  </div>
                </div>
                
                <div className="p-8">
                  <div className="flex items-center justify-between mb-4">
                    <span className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded-full text-sm font-medium border border-blue-500/30">
                      {course.category}
                    </span>
                    <div className="flex items-center space-x-1">
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <span className="text-white font-medium">{course.rating}</span>
                      <span className="text-gray-400 text-sm">({course.reviews})</span>
                    </div>
                  </div>
                  
                  <h3 className="text-xl font-bold text-white mb-4 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-blue-400 group-hover:to-purple-400 transition-all duration-300">
                    {course.title}
                  </h3>
                  
                  <p className="text-gray-300 mb-6 leading-relaxed">{course.description}</p>
                  
                  <div className="grid grid-cols-3 gap-4 mb-6 text-center">
                    <div className="flex flex-col items-center">
                      <Clock className="w-5 h-5 text-blue-400 mb-1" />
                      <span className="text-gray-300 text-sm">{course.duration}</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <BookOpen className="w-5 h-5 text-purple-400 mb-1" />
                      <span className="text-gray-300 text-sm">{course.lessons} lessons</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <Users className="w-5 h-5 text-green-400 mb-1" />
                      <span className="text-gray-300 text-sm">{course.students} students</span>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-2 mb-6">
                    {course.skills.slice(0, 3).map((skill, skillIndex) => (
                      <span 
                        key={skillIndex}
                        className="px-3 py-1 bg-gray-800/50 text-gray-300 rounded-full text-sm font-medium border border-gray-700/50"
                      >
                        {skill}
                      </span>
                    ))}
                    {course.skills.length > 3 && (
                      <span className="px-3 py-1 bg-gray-800/50 text-gray-300 rounded-full text-sm font-medium border border-gray-700/50">
                        +{course.skills.length - 3} more
                      </span>
                    )}
                  </div>
                  
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center space-x-2">
                      <span className="text-2xl font-bold text-white">{course.price}</span>
                      <span className="text-gray-400 line-through">{course.originalPrice}</span>
                    </div>
                    <button
                      onClick={() => downloadSyllabus(course)}
                      className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors duration-200"
                    >
                      <Download className="w-4 h-4" />
                      <span className="text-sm">Syllabus</span>
                    </button>
                  </div>
                  
                  <div className="flex space-x-3">
                    <button
                      onClick={() => enrollCourse(course)}
                      className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl font-semibold hover:from-blue-600 hover:to-purple-600 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-blue-500/25"
                    >
                      Enroll Now
                    </button>
                    <button
                      onClick={() => previewCourse(course)}
                      className="px-6 py-3 border border-gray-600 text-gray-300 rounded-xl font-semibold hover:border-white hover:text-white transition-all duration-300 backdrop-blur-sm"
                    >
                      Preview
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Courses;