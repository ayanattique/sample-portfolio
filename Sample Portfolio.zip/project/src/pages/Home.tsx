import React from 'react';
import Hero from '../components/Hero';
import ClientReviews from '../components/ClientReviews';

const Home = () => {
  return (
    <div className="pt-20">
      <Hero />
      <ClientReviews />
    </div>
  );
};

export default Home;