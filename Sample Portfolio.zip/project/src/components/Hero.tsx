import React from 'react';
import { BarChart3, TrendingUp, PieChart, Download, Mail, Github, Linkedin, Youtube, Instagram, Facebook } from 'lucide-react';

const Hero = () => {
  const [displayedText, setDisplayedText] = React.useState('');
  const [currentIndex, setCurrentIndex] = React.useState(0);
  const [showCursor, setShowCursor] = React.useState(true);
  const [projectsCount, setProjectsCount] = React.useState(0);
  const [experienceCount, setExperienceCount] = React.useState(0);
  const [clientsCount, setClientsCount] = React.useState(0);
  const [hasAnimated, setHasAnimated] = React.useState(false);
  const statsRef = React.useRef<HTMLDivElement>(null);
  const fullName = "Muhammad Ayan";

  React.useEffect(() => {
    if (currentIndex < fullName.length) {
      const timeout = setTimeout(() => {
        setDisplayedText(prev => prev + fullName[currentIndex]);
        setCurrentIndex(prev => prev + 1);
      }, 150); // Typing speed
      return () => clearTimeout(timeout);
    } else {
      // Blinking cursor effect after typing is complete
      const cursorInterval = setInterval(() => {
        setShowCursor(prev => !prev);
      }, 530);
      return () => clearInterval(cursorInterval);
    }
  }, [currentIndex, fullName]);

  // Intersection Observer for stats animation
  React.useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !hasAnimated) {
            setHasAnimated(true);
            
            // Animate projects counter
            let projectsStart = 0;
            const projectsEnd = 50;
            const projectsIncrement = projectsEnd / 60;
            const projectsTimer = setInterval(() => {
              projectsStart += projectsIncrement;
              if (projectsStart >= projectsEnd) {
                setProjectsCount(projectsEnd);
                clearInterval(projectsTimer);
              } else {
                setProjectsCount(Math.floor(projectsStart));
              }
            }, 30);

            // Animate experience counter
            let experienceStart = 0;
            const experienceEnd = 5;
            const experienceIncrement = experienceEnd / 40;
            const experienceTimer = setInterval(() => {
              experienceStart += experienceIncrement;
              if (experienceStart >= experienceEnd) {
                setExperienceCount(experienceEnd);
                clearInterval(experienceTimer);
              } else {
                setExperienceCount(Math.floor(experienceStart));
              }
            }, 50);

            // Animate clients counter
            let clientsStart = 0;
            const clientsEnd = 25;
            const clientsIncrement = clientsEnd / 50;
            const clientsTimer = setInterval(() => {
              clientsStart += clientsIncrement;
              if (clientsStart >= clientsEnd) {
                setClientsCount(clientsEnd);
                clearInterval(clientsTimer);
              } else {
                setClientsCount(Math.floor(clientsStart));
              }
            }, 40);
          }
        });
      },
      { threshold: 0.5 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => {
      if (statsRef.current) {
        observer.unobserve(statsRef.current);
      }
    };
  }, [hasAnimated]);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const headerHeight = 80;
      const elementPosition = element.offsetTop - headerHeight;
      window.scrollTo({
        top: elementPosition,
        behavior: 'smooth'
      });
    }
  };

  const downloadResume = () => {
    const resumeContent = `
MUHAMMAD AYAN
Data Analytics Expert

CONTACT:
Email: muhammadayanprivate@gmail.com
Phone: +92 302 0055418
Location: Pakistan
LinkedIn: linkedin.com/in/muhammadayan
GitHub: github.com/muhammadayan

PROFESSIONAL SUMMARY:
Senior Data Analytics Expert with 5+ years of experience transforming complex business data into strategic insights. Specialized in statistical analysis, predictive modeling, and data visualization. Proven track record of delivering measurable business impact across finance, healthcare, retail, and technology sectors.

EXPERIENCE:
Senior Data Analytics Expert (2019-Present)
• Led 50+ analytics projects with measurable business impact
• Improved customer retention by 23% through behavior analysis
• Enhanced sales forecast accuracy by 35% using predictive models
• Reduced portfolio risk by 18% through advanced statistical modeling
• Created interactive dashboards serving 100+ stakeholders
• Implemented machine learning algorithms for demand forecasting

Data Analyst (2017-2019)
• Developed automated reporting systems reducing manual work by 60%
• Conducted A/B testing for marketing campaigns improving ROI by 25%
• Built customer segmentation models for targeted marketing
• Analyzed website performance data to optimize user experience

TECHNICAL SKILLS:
Programming: Python, R, SQL, JavaScript
Analytics Tools: Tableau, Power BI, Google Analytics, Excel
Statistical Software: SPSS, SAS, Stata
Machine Learning: Scikit-learn, TensorFlow, Pandas, NumPy
Databases: MySQL, PostgreSQL, MongoDB
Cloud Platforms: AWS, Google Cloud Platform

EDUCATION:
Master of Science in Data Science
University of California, Berkeley (2017)

Bachelor of Science in Statistics
Stanford University (2015)

CERTIFICATIONS:
• Tableau Desktop Certified Professional
• Google Analytics Certified
• AWS Certified Data Analytics
• Microsoft Power BI Certified

KEY ACHIEVEMENTS:
• Reduced customer churn by 23% through predictive analytics
• Improved sales forecasting accuracy by 35%
• Decreased inventory costs by 22% through optimization models
• Enhanced marketing campaign ROI by 31%
• Reduced financial portfolio risk by 18%
• Improved patient outcomes by 28% in healthcare analytics

PROJECTS:
• Customer Behavior Analytics Dashboard
• Sales Performance Analytics Suite
• Financial Risk Assessment Model
• Healthcare Outcomes Analysis
• Retail Inventory Optimization
• Marketing Campaign Performance Analysis
    `;
    
    const blob = new Blob([resumeContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Muhammad_Ayan_Resume.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  const openEmailClient = () => {
    window.location.href = 'mailto:muhammadayanprivate@gmail.com?subject=Analytics Project Inquiry&body=Hi Muhammad,%0D%0A%0D%0AI would like to discuss a data analytics project with you.%0D%0A%0D%0AProject Details:%0D%0A- Industry: %0D%0A- Data Type: %0D%0A- Business Objective: %0D%0A- Timeline: %0D%0A%0D%0APlease let me know your availability for a consultation.%0D%0A%0D%0ABest regards';
  };

  const scheduleConsultation = () => {
    // Open Calendly or similar scheduling tool
    window.open('https://calendly.com/muhammadayan/analytics-consultation', '_blank', 'noopener,noreferrer');
  };

  const openPortfolio = () => {
    // Navigate to portfolio page
    window.location.href = '/portfolio';
  };

  const openLinkedIn = () => {
    window.open('https://linkedin.com/in/muhammadayan', '_blank', 'noopener,noreferrer');
  };

  const openGitHub = () => {
    window.open('https://github.com/muhammadayan', '_blank', 'noopener,noreferrer');
  };

  const openYouTube = () => {
    window.open('https://youtube.com/@muhammadayan', '_blank', 'noopener,noreferrer');
  };

  const openInstagram = () => {
    window.open('https://instagram.com/muhammadayan', '_blank', 'noopener,noreferrer');
  };

  const openFacebook = () => {
    window.open('https://facebook.com/muhammadayan', '_blank', 'noopener,noreferrer');
  };

  const openTikTok = () => {
    window.open('https://tiktok.com/@muhammadayan', '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="home" className="min-h-screen bg-black flex items-center justify-center relative overflow-hidden">
      {/* Professional animated background */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Animated geometric patterns */}
        <div className="absolute inset-0">
          {/* Large floating orbs */}
          <div className="absolute top-1/4 left-1/6 w-96 h-96 bg-gradient-to-r from-blue-500/8 to-transparent rounded-full blur-3xl animate-float-slow"></div>
          <div className="absolute bottom-1/3 right-1/6 w-80 h-80 bg-gradient-to-l from-purple-500/8 to-transparent rounded-full blur-3xl animate-float-slow-reverse"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-r from-blue-400/6 to-purple-400/6 rounded-full blur-2xl animate-pulse-slow"></div>
          
          {/* Animated lines */}
          <div className="absolute top-0 left-0 w-full h-full">
            <div className="absolute top-1/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-blue-500/20 to-transparent animate-slide-right"></div>
            <div className="absolute top-1/2 left-0 w-full h-px bg-gradient-to-r from-transparent via-purple-500/20 to-transparent animate-slide-left"></div>
            <div className="absolute top-3/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-blue-400/15 to-transparent animate-slide-right-slow"></div>
          </div>
          
          {/* Subtle grid pattern */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(59,130,246,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(59,130,246,0.03)_1px,transparent_1px)] bg-[size:60px_60px] animate-grid-move"></div>
          
          {/* Floating particles */}
          <div className="absolute top-1/6 left-1/4 w-2 h-2 bg-blue-400/40 rounded-full animate-float-particle"></div>
          <div className="absolute top-1/3 right-1/4 w-1 h-1 bg-purple-400/40 rounded-full animate-float-particle-reverse"></div>
          <div className="absolute bottom-1/4 left-1/3 w-1.5 h-1.5 bg-blue-300/30 rounded-full animate-float-particle-slow"></div>
          <div className="absolute bottom-1/6 right-1/3 w-1 h-1 bg-purple-300/30 rounded-full animate-float-particle"></div>
          
          {/* Radial gradients */}
          <div className="absolute top-0 left-0 w-full h-full bg-radial-gradient-1 opacity-30"></div>
          <div className="absolute bottom-0 right-0 w-full h-full bg-radial-gradient-2 opacity-20"></div>
        </div>
      </div>

      <div className="relative z-10 text-center px-6 lg:px-8 max-w-6xl mx-auto">
        <div className="space-y-12">
          {/* Professional floating analytics icons */}
          <div className="flex justify-center space-x-16 mb-16">
            <div className="animate-float-professional">
              <div className="p-5 bg-gradient-to-br from-blue-500/15 to-blue-600/10 rounded-3xl backdrop-blur-sm border border-blue-500/20 shadow-lg shadow-blue-500/10">
                <BarChart3 className="w-10 h-10 text-blue-400" />
              </div>
            </div>
            <div className="animate-float-professional-delay">
              <div className="p-5 bg-gradient-to-br from-purple-500/15 to-purple-600/10 rounded-3xl backdrop-blur-sm border border-purple-500/20 shadow-lg shadow-purple-500/10">
                <TrendingUp className="w-10 h-10 text-purple-400" />
              </div>
            </div>
            <div className="animate-float-professional-delay-2">
              <div className="p-5 bg-gradient-to-br from-blue-500/15 to-purple-500/10 rounded-3xl backdrop-blur-sm border border-blue-500/20 shadow-lg shadow-blue-500/10">
                <PieChart className="w-10 h-10 text-blue-400" />
              </div>
            </div>
          </div>

          <div className="space-y-10">
            {/* Typewriter effect for name */}
            <div className="min-h-[200px] flex items-center justify-center">
              <h1 className="text-6xl md:text-8xl font-bold text-white tracking-tight leading-tight">
                <span className="block mb-4">
                  {displayedText}
                  <span className={`inline-block w-1 h-16 md:h-20 bg-gradient-to-b from-blue-400 to-purple-400 ml-2 ${showCursor ? 'opacity-100' : 'opacity-0'} transition-opacity duration-100`}></span>
                </span>
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-400 to-blue-400 bg-size-200 animate-gradient-professional">
                  Data Analytics Expert
                </span>
              </h1>
            </div>
            
            <div className="space-y-6 animate-fade-in-professional">
              <p className="text-2xl md:text-3xl text-gray-300 font-light tracking-wide">
                Transforming Data Into Strategic Insights
              </p>
              <div className="w-32 h-1 bg-gradient-to-r from-blue-400 to-purple-400 mx-auto rounded-full shadow-lg shadow-blue-500/25"></div>
            </div>
            
            <p className="text-xl text-gray-400 mb-16 max-w-4xl mx-auto leading-relaxed animate-fade-in-professional-delay font-light">
              Specialized in advanced statistical analysis, predictive modeling, and compelling data visualizations 
              that drive informed decision-making and deliver measurable business impact.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center animate-fade-in-professional-delay-2">
              <button
                onClick={openPortfolio}
                className="group px-12 py-5 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-full font-semibold hover:from-blue-600 hover:to-purple-600 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-blue-500/30 relative overflow-hidden"
              >
                <span className="relative z-10 flex items-center justify-center space-x-2">
                  <span>Explore Analytics Portfolio</span>
                  <BarChart3 className="w-5 h-5" />
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </button>
              <button
                onClick={openEmailClient}
                className="px-12 py-5 border-2 border-gray-600 text-gray-300 rounded-full font-semibold hover:border-white hover:text-white hover:bg-white/5 transition-all duration-300 transform hover:scale-105 backdrop-blur-sm flex items-center justify-center space-x-2 hover:shadow-lg hover:shadow-white/10"
              >
                <Mail className="w-5 h-5" />
                <span>Start Collaboration</span>
              </button>
            </div>

            {/* Professional action buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mt-10 animate-fade-in-professional-delay-3">
              <button
                onClick={downloadResume}
                className="px-10 py-4 bg-gray-900/50 text-gray-300 rounded-full font-medium hover:bg-gray-800/50 hover:text-white transition-all duration-300 transform hover:scale-105 backdrop-blur-sm flex items-center justify-center space-x-2 border border-gray-700/50 hover:border-gray-600/50 hover:shadow-lg hover:shadow-gray-500/10"
              >
                <Download className="w-4 h-4" />
                <span>Download Resume</span>
              </button>
              <button
                onClick={scheduleConsultation}
                className="px-10 py-4 bg-gray-900/50 text-gray-300 rounded-full font-medium hover:bg-gray-800/50 hover:text-white transition-all duration-300 transform hover:scale-105 backdrop-blur-sm border border-gray-700/50 hover:border-gray-600/50 hover:shadow-lg hover:shadow-gray-500/10"
              >
                Schedule Consultation
              </button>
            </div>

            {/* Social Media Links */}
            <div className="animate-fade-in-professional-delay-3">
              <h3 className="text-white font-semibold text-lg mb-6">Connect With Me</h3>
              <div className="flex justify-center space-x-4">
                <button
                  onClick={openLinkedIn}
                  className="w-12 h-12 bg-gradient-to-br from-gray-800/50 to-gray-700/50 rounded-xl flex items-center justify-center hover:from-gray-700/50 hover:to-gray-600/50 transition-all duration-300 border border-gray-700/50 hover:border-gray-600/50 group"
                >
                  <Linkedin className="w-5 h-5 text-gray-300 group-hover:text-white transition-colors duration-200" />
                </button>
                <button
                  onClick={openGitHub}
                  className="w-12 h-12 bg-gradient-to-br from-gray-800/50 to-gray-700/50 rounded-xl flex items-center justify-center hover:from-gray-700/50 hover:to-gray-600/50 transition-all duration-300 border border-gray-700/50 hover:border-gray-600/50 group"
                >
                  <Github className="w-5 h-5 text-gray-300 group-hover:text-white transition-colors duration-200" />
                </button>
                <button
                  onClick={openYouTube}
                  className="w-12 h-12 bg-gradient-to-br from-gray-800/50 to-gray-700/50 rounded-xl flex items-center justify-center hover:from-gray-700/50 hover:to-gray-600/50 transition-all duration-300 border border-gray-700/50 hover:border-gray-600/50 group"
                >
                  <Youtube className="w-5 h-5 text-gray-300 group-hover:text-white transition-colors duration-200" />
                </button>
                <button
                  onClick={openInstagram}
                  className="w-12 h-12 bg-gradient-to-br from-gray-800/50 to-gray-700/50 rounded-xl flex items-center justify-center hover:from-gray-700/50 hover:to-gray-600/50 transition-all duration-300 border border-gray-700/50 hover:border-gray-600/50 group"
                >
                  <Instagram className="w-5 h-5 text-gray-300 group-hover:text-white transition-colors duration-200" />
                </button>
                <button
                  onClick={openFacebook}
                  className="w-12 h-12 bg-gradient-to-br from-gray-800/50 to-gray-700/50 rounded-xl flex items-center justify-center hover:from-gray-700/50 hover:to-gray-600/50 transition-all duration-300 border border-gray-700/50 hover:border-gray-600/50 group"
                >
                  <Facebook className="w-5 h-5 text-gray-300 group-hover:text-white transition-colors duration-200" />
                </button>
                <button
                  onClick={openTikTok}
                  className="w-12 h-12 bg-gradient-to-br from-gray-800/50 to-gray-700/50 rounded-xl flex items-center justify-center hover:from-gray-700/50 hover:to-gray-600/50 transition-all duration-300 border border-gray-700/50 hover:border-gray-600/50 group"
                >
                  <svg className="w-5 h-5 text-gray-300 group-hover:text-white transition-colors duration-200" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
                  </svg>
                </button>
              </div>
            </div>

            {/* Animated stats counters */}
            <div ref={statsRef} className="grid grid-cols-3 gap-8 mt-24 animate-fade-in-professional-delay-3">
              <div className="text-center group">
                <div className="text-4xl md:text-5xl font-bold text-white mb-3 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-blue-400 group-hover:to-purple-400 transition-all duration-300">
                  {projectsCount}+
                </div>
                <div className="text-gray-400 text-sm uppercase tracking-wider font-medium">Analytics Projects</div>
              </div>
              <div className="text-center group">
                <div className="text-4xl md:text-5xl font-bold text-white mb-3 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-blue-400 group-hover:to-purple-400 transition-all duration-300">
                  {experienceCount}+
                </div>
                <div className="text-gray-400 text-sm uppercase tracking-wider font-medium">Years Experience</div>
              </div>
              <div className="text-center group">
                <div className="text-4xl md:text-5xl font-bold text-white mb-3 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-blue-400 group-hover:to-purple-400 transition-all duration-300">
                  {clientsCount}+
                </div>
                <div className="text-gray-400 text-sm uppercase tracking-wider font-medium">Happy Clients</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;