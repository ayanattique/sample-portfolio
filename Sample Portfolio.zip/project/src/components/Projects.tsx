import React from 'react';
import { ExternalLink, Github, BarChart3, TrendingUp, PieChart, LineChart, Calendar, Award, Eye } from 'lucide-react';

const Projects = () => {
  const projects = [
    {
      title: "Customer Behavior Analytics Dashboard",
      description: "Comprehensive analysis of customer purchasing patterns and behavior trends using advanced statistical methods. Created interactive dashboards that identified key customer segments and improved retention rates by 23%.",
      tech: ["Python", "Tableau", "SQL", "Statistical Analysis"],
      category: "Customer Analytics",
      icon: <BarChart3 className="w-6 h-6 text-blue-400" />,
      image: "https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=800",
      demoLink: "https://public.tableau.com/views/CustomerAnalytics/Dashboard",
      githubLink: "https://github.com/muhammadayan/customer-analytics",
      date: "Dec 2023",
      impact: "23% increase in customer retention"
    },
    {
      title: "Sales Performance Analytics Suite",
      description: "Built a comprehensive sales analytics platform analyzing performance across multiple regions and product lines. Implemented predictive forecasting models that improved quarterly sales predictions accuracy by 35%.",
      tech: ["Power BI", "SQL", "Excel", "Statistical Modeling"],
      category: "Sales Analytics",
      icon: <TrendingUp className="w-6 h-6 text-purple-400" />,
      image: "https://images.pexels.com/photos/669615/pexels-photo-669615.jpeg?auto=compress&cs=tinysrgb&w=800",
      demoLink: "https://app.powerbi.com/view?r=eyJrIjoiSalesAnalytics",
      githubLink: "https://github.com/muhammadayan/sales-analytics",
      date: "Nov 2023",
      impact: "35% improvement in forecast accuracy"
    },
    {
      title: "Financial Risk Assessment Model",
      description: "Developed sophisticated risk analytics models for financial portfolio assessment. Used advanced statistical techniques to analyze market volatility and created risk scoring algorithms that reduced portfolio risk by 18%.",
      tech: ["R", "Python", "Statistical Analysis", "Risk Modeling"],
      category: "Financial Analytics",
      icon: <LineChart className="w-6 h-6 text-blue-400" />,
      image: "https://images.pexels.com/photos/186461/pexels-photo-186461.jpeg?auto=compress&cs=tinysrgb&w=800",
      demoLink: "https://rpubs.com/muhammadayan/financial-risk-model",
      githubLink: "https://github.com/muhammadayan/financial-risk-analytics",
      date: "Oct 2023",
      impact: "18% reduction in portfolio risk"
    },
    {
      title: "Healthcare Outcomes Analysis",
      description: "Analyzed patient treatment outcomes and healthcare delivery efficiency using statistical methods. Created predictive models for treatment success rates and identified factors that improved patient outcomes by 28%.",
      tech: ["R", "Tableau", "Statistical Analysis", "Healthcare Analytics"],
      category: "Healthcare Analytics",
      icon: <PieChart className="w-6 h-6 text-purple-400" />,
      image: "https://images.pexels.com/photos/40568/medical-appointment-doctor-healthcare-40568.jpeg?auto=compress&cs=tinysrgb&w=800",
      demoLink: "https://public.tableau.com/views/HealthcareOutcomes/Dashboard",
      githubLink: "https://github.com/muhammadayan/healthcare-analytics",
      date: "Sep 2023",
      impact: "28% improvement in patient outcomes"
    },
    {
      title: "Retail Inventory Optimization",
      description: "Implemented advanced analytics for retail inventory management using demand forecasting and trend analysis. Optimized stock levels across multiple locations, reducing inventory costs by 22% while maintaining service levels.",
      tech: ["Python", "SQL", "Forecasting", "Optimization"],
      category: "Retail Analytics",
      icon: <BarChart3 className="w-6 h-6 text-blue-400" />,
      image: "https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&w=800",
      demoLink: "https://colab.research.google.com/drive/inventory-optimization",
      githubLink: "https://github.com/muhammadayan/retail-inventory-analytics",
      date: "Aug 2023",
      impact: "22% reduction in inventory costs"
    },
    {
      title: "Marketing Campaign Performance Analysis",
      description: "Comprehensive analysis of multi-channel marketing campaigns using attribution modeling and statistical analysis. Identified optimal channel mix and budget allocation, improving campaign ROI by 31%.",
      tech: ["Google Analytics", "Python", "Statistical Analysis", "Attribution Modeling"],
      category: "Marketing Analytics",
      icon: <TrendingUp className="w-6 h-6 text-purple-400" />,
      image: "https://images.pexels.com/photos/267389/pexels-photo-267389.jpeg?auto=compress&cs=tinysrgb&w=800",
      demoLink: "https://datastudio.google.com/reporting/marketing-analytics",
      githubLink: "https://github.com/muhammadayan/marketing-analytics",
      date: "Jul 2023",
      impact: "31% improvement in campaign ROI"
    }
  ];

  const categories = ["All", "Customer Analytics", "Sales Analytics", "Financial Analytics", "Healthcare Analytics", "Retail Analytics", "Marketing Analytics"];
  const [selectedCategory, setSelectedCategory] = React.useState("All");

  const filteredProjects = selectedCategory === "All" 
    ? projects 
    : projects.filter(project => project.category === selectedCategory);

  const openProject = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const viewProjectDetails = (project: any) => {
    alert(`Project: ${project.title}\n\nDescription: ${project.description}\n\nTechnologies: ${project.tech.join(', ')}\n\nImpact: ${project.impact}`);
  };

  return (
    <section id="projects" className="py-24 bg-gradient-to-b from-black to-gray-950 relative">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.01)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.01)_1px,transparent_1px)] bg-[size:100px_100px]"></div>
      
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <div className="inline-block px-4 py-2 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-full border border-blue-500/20 mb-6">
            <span className="text-blue-400 text-sm font-medium tracking-wider uppercase">Portfolio</span>
          </div>
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-8 tracking-tight">
            Featured Analytics
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
              Projects
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed mb-12">
            Explore my portfolio of data analytics projects that have delivered measurable business impact
          </p>
          
          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-16">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-3 rounded-full font-medium transition-all duration-300 backdrop-blur-sm ${
                  selectedCategory === category
                    ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg shadow-blue-500/25 border border-blue-500/50'
                    : 'bg-gray-800/50 text-gray-300 hover:bg-gray-700/50 hover:text-white border border-gray-700/50 hover:border-gray-600/50'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <div 
              key={index}
              className="group bg-gradient-to-br from-gray-900/50 to-gray-800/50 rounded-3xl overflow-hidden hover:from-gray-800/50 hover:to-gray-700/50 transition-all duration-500 transform hover:scale-105 border border-gray-700/50 hover:border-gray-600/50 backdrop-blur-sm relative project-glow"
            >
              {/* Glow effect on hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-3xl"></div>
              <div className="absolute inset-0 shadow-2xl shadow-blue-500/0 group-hover:shadow-blue-500/20 transition-all duration-500 rounded-3xl"></div>
              
              <div className="relative overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-56 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                
                {/* Project actions */}
                <div className="absolute top-4 right-4 flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <button
                    onClick={() => openProject(project.demoLink)}
                    className="p-3 bg-black/70 rounded-full hover:bg-black/90 transition-colors duration-200 backdrop-blur-sm"
                    title="View Live Demo"
                  >
                    <ExternalLink className="w-4 h-4 text-white" />
                  </button>
                  <button
                    onClick={() => openProject(project.githubLink)}
                    className="p-3 bg-black/70 rounded-full hover:bg-black/90 transition-colors duration-200 backdrop-blur-sm"
                    title="View Source Code"
                  >
                    <Github className="w-4 h-4 text-white" />
                  </button>
                </div>
                
                {/* Category badge */}
                <div className="absolute bottom-4 left-4 flex items-center space-x-2 bg-black/70 rounded-full px-4 py-2 backdrop-blur-sm">
                  {project.icon}
                  <span className="text-white font-medium text-sm">{project.category}</span>
                </div>
              </div>
              
              <div className="p-8 relative z-10">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold text-white group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-blue-400 group-hover:to-purple-400 transition-all duration-300">
                    {project.title}
                  </h3>
                  <div className="flex items-center text-gray-400 text-sm">
                    <Calendar className="w-4 h-4 mr-1" />
                    {project.date}
                  </div>
                </div>
                
                <p className="text-gray-300 mb-6 leading-relaxed">{project.description}</p>
                
                {/* Impact badge */}
                <div className="flex items-center space-x-2 mb-6 p-3 bg-gradient-to-r from-green-500/10 to-blue-500/10 rounded-lg border border-green-500/20">
                  <Award className="w-4 h-4 text-green-400" />
                  <span className="text-green-400 font-medium text-sm">{project.impact}</span>
                </div>
                
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tech.map((tech, techIndex) => (
                    <span 
                      key={techIndex}
                      className="px-3 py-1 bg-gray-800/50 text-gray-300 rounded-full text-sm font-medium border border-gray-700/50"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                
                <div className="flex space-x-4">
                  <button
                    onClick={() => openProject(project.demoLink)}
                    className="flex items-center space-x-2 text-blue-400 hover:text-blue-300 transition-colors duration-200 font-medium"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>View Analysis</span>
                  </button>
                  <button
                    onClick={() => openProject(project.githubLink)}
                    className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors duration-200 font-medium"
                  >
                    <Github className="w-4 h-4" />
                    <span>Code</span>
                  </button>
                  <button
                    onClick={() => viewProjectDetails(project)}
                    className="flex items-center space-x-2 text-purple-400 hover:text-purple-300 transition-colors duration-200 font-medium"
                  >
                    <Eye className="w-4 h-4" />
                    <span>Details</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;