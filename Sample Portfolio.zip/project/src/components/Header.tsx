import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, BarChart3 } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black/95 backdrop-blur-xl border-b border-gray-800/50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <Link 
            to="/"
            className="flex items-center space-x-3 hover:opacity-80 transition-opacity duration-200"
          >
            <div className="p-2 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl">
              <BarChart3 className="w-6 h-6 text-blue-400" />
            </div>
            <div>
              <div className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                Muhammad Ayan
              </div>
              <div className="text-xs text-gray-400 font-medium tracking-wider">
                DATA ANALYTICS EXPERT
              </div>
            </div>
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:block">
            <div className="flex items-center space-x-8">
              <Link
                to="/"
                className={`text-gray-300 hover:text-white transition-all duration-300 font-medium tracking-wide relative group ${
                  isActive('/') ? 'text-white' : ''
                }`}
              >
                Home
                <span className={`absolute -bottom-1 left-0 h-0.5 bg-gradient-to-r from-blue-400 to-purple-400 transition-all duration-300 ${
                  isActive('/') ? 'w-full' : 'w-0 group-hover:w-full'
                }`}></span>
              </Link>
              <Link
                to="/about"
                className={`text-gray-300 hover:text-white transition-all duration-300 font-medium tracking-wide relative group ${
                  isActive('/about') ? 'text-white' : ''
                }`}
              >
                About
                <span className={`absolute -bottom-1 left-0 h-0.5 bg-gradient-to-r from-blue-400 to-purple-400 transition-all duration-300 ${
                  isActive('/about') ? 'w-full' : 'w-0 group-hover:w-full'
                }`}></span>
              </Link>
              <Link
                to="/portfolio"
                className={`text-gray-300 hover:text-white transition-all duration-300 font-medium tracking-wide relative group ${
                  isActive('/portfolio') ? 'text-white' : ''
                }`}
              >
                Portfolio
                <span className={`absolute -bottom-1 left-0 h-0.5 bg-gradient-to-r from-blue-400 to-purple-400 transition-all duration-300 ${
                  isActive('/portfolio') ? 'w-full' : 'w-0 group-hover:w-full'
                }`}></span>
              </Link>
              <Link
                to="/blog"
                className={`text-gray-300 hover:text-white transition-all duration-300 font-medium tracking-wide relative group ${
                  isActive('/blog') ? 'text-white' : ''
                }`}
              >
                Blog
                <span className={`absolute -bottom-1 left-0 h-0.5 bg-gradient-to-r from-blue-400 to-purple-400 transition-all duration-300 ${
                  isActive('/blog') ? 'w-full' : 'w-0 group-hover:w-full'
                }`}></span>
              </Link>
              <Link
                to="/courses"
                className={`text-gray-300 hover:text-white transition-all duration-300 font-medium tracking-wide relative group ${
                  isActive('/courses') ? 'text-white' : ''
                }`}
              >
                Courses
                <span className={`absolute -bottom-1 left-0 h-0.5 bg-gradient-to-r from-blue-400 to-purple-400 transition-all duration-300 ${
                  isActive('/courses') ? 'w-full' : 'w-0 group-hover:w-full'
                }`}></span>
              </Link>
              <Link
                to="/contact"
                className="px-6 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-full font-medium hover:from-blue-600 hover:to-purple-600 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-blue-500/25"
              >
                Contact
              </Link>
            </div>
          </nav>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-300 hover:text-white p-2 transition-colors duration-200"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden">
          <div className="px-4 pt-4 pb-6 space-y-4 bg-black/98 backdrop-blur-xl border-t border-gray-800/50">
            <Link
              to="/"
              onClick={() => setIsMenuOpen(false)}
              className={`block w-full text-left px-4 py-3 rounded-lg transition-all duration-200 ${
                isActive('/') 
                  ? 'text-white bg-gray-800/50' 
                  : 'text-gray-300 hover:text-white hover:bg-gray-800/50'
              }`}
            >
              Home
            </Link>
            <Link
              to="/about"
              onClick={() => setIsMenuOpen(false)}
              className={`block w-full text-left px-4 py-3 rounded-lg transition-all duration-200 ${
                isActive('/about') 
                  ? 'text-white bg-gray-800/50' 
                  : 'text-gray-300 hover:text-white hover:bg-gray-800/50'
              }`}
            >
              About
            </Link>
            <Link
              to="/portfolio"
              onClick={() => setIsMenuOpen(false)}
              className={`block w-full text-left px-4 py-3 rounded-lg transition-all duration-200 ${
                isActive('/portfolio') 
                  ? 'text-white bg-gray-800/50' 
                  : 'text-gray-300 hover:text-white hover:bg-gray-800/50'
              }`}
            >
              Portfolio
            </Link>
            <Link
              to="/blog"
              onClick={() => setIsMenuOpen(false)}
              className={`block w-full text-left px-4 py-3 rounded-lg transition-all duration-200 ${
                isActive('/blog') 
                  ? 'text-white bg-gray-800/50' 
                  : 'text-gray-300 hover:text-white hover:bg-gray-800/50'
              }`}
            >
              Blog
            </Link>
            <Link
              to="/courses"
              onClick={() => setIsMenuOpen(false)}
              className={`block w-full text-left px-4 py-3 rounded-lg transition-all duration-200 ${
                isActive('/courses') 
                  ? 'text-white bg-gray-800/50' 
                  : 'text-gray-300 hover:text-white hover:bg-gray-800/50'
              }`}
            >
              Courses
            </Link>
            <Link
              to="/contact"
              onClick={() => setIsMenuOpen(false)}
              className={`block w-full text-left px-4 py-3 rounded-lg transition-all duration-200 ${
                isActive('/contact') 
                  ? 'text-white bg-gray-800/50' 
                  : 'text-gray-300 hover:text-white hover:bg-gray-800/50'
              }`}
            >
              Contact
            </Link>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;