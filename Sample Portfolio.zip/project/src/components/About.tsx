import React from 'react';
import { BarChart3, TrendingUp, PieChart, LineChart, Activity, Target } from 'lucide-react';

const About = () => {
  const [skillsAnimated, setSkillsAnimated] = React.useState(false);
  const [statisticalAnalysis, setStatisticalAnalysis] = React.useState(0);
  const [dataVisualization, setDataVisualization] = React.useState(0);
  const [predictiveAnalytics, setPredictiveAnalytics] = React.useState(0);
  const [businessIntelligence, setBusinessIntelligence] = React.useState(0);
  const skillsRef = React.useRef<HTMLDivElement>(null);

  // Intersection Observer for skills animation
  React.useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !skillsAnimated) {
            setSkillsAnimated(true);
            
            // Animate Statistical Analysis to 95%
            let statStart = 0;
            const statEnd = 95;
            const statIncrement = statEnd / 80;
            const statTimer = setInterval(() => {
              statStart += statIncrement;
              if (statStart >= statEnd) {
                setStatisticalAnalysis(statEnd);
                clearInterval(statTimer);
              } else {
                setStatisticalAnalysis(Math.floor(statStart));
              }
            }, 25);

            // Animate Data Visualization to 92%
            let vizStart = 0;
            const vizEnd = 92;
            const vizIncrement = vizEnd / 75;
            const vizTimer = setInterval(() => {
              vizStart += vizIncrement;
              if (vizStart >= vizEnd) {
                setDataVisualization(vizEnd);
                clearInterval(vizTimer);
              } else {
                setDataVisualization(Math.floor(vizStart));
              }
            }, 30);

            // Animate Predictive Analytics to 88%
            let predStart = 0;
            const predEnd = 88;
            const predIncrement = predEnd / 70;
            const predTimer = setInterval(() => {
              predStart += predIncrement;
              if (predStart >= predEnd) {
                setPredictiveAnalytics(predEnd);
                clearInterval(predTimer);
              } else {
                setPredictiveAnalytics(Math.floor(predStart));
              }
            }, 35);

            // Animate Business Intelligence to 90%
            let biStart = 0;
            const biEnd = 90;
            const biIncrement = biEnd / 72;
            const biTimer = setInterval(() => {
              biStart += biIncrement;
              if (biStart >= biEnd) {
                setBusinessIntelligence(biEnd);
                clearInterval(biTimer);
              } else {
                setBusinessIntelligence(Math.floor(biStart));
              }
            }, 32);
          }
        });
      },
      { threshold: 0.3 }
    );

    if (skillsRef.current) {
      observer.observe(skillsRef.current);
    }

    return () => {
      if (skillsRef.current) {
        observer.unobserve(skillsRef.current);
      }
    };
  }, [skillsAnimated]);

  const skills = [
    {
      icon: <BarChart3 className="w-8 h-8 text-blue-400" />,
      title: "Statistical Analysis",
      description: "Advanced statistical modeling, hypothesis testing, and inferential statistics to extract meaningful insights from complex datasets"
    },
    {
      icon: <TrendingUp className="w-8 h-8 text-purple-400" />,
      title: "Predictive Analytics",
      description: "Building forecasting models and trend analysis to predict future outcomes and support strategic planning"
    },
    {
      icon: <PieChart className="w-8 h-8 text-blue-400" />,
      title: "Data Visualization",
      description: "Creating compelling dashboards and interactive visualizations using Tableau, Power BI, and advanced charting libraries"
    },
    {
      icon: <LineChart className="w-8 h-8 text-purple-400" />,
      title: "Business Intelligence",
      description: "Transforming raw data into actionable business insights through comprehensive reporting and KPI analysis"
    },
    {
      icon: <Activity className="w-8 h-8 text-blue-400" />,
      title: "Performance Analytics",
      description: "Analyzing business performance metrics, customer behavior, and operational efficiency to drive optimization"
    },
    {
      icon: <Target className="w-8 h-8 text-purple-400" />,
      title: "Strategic Insights",
      description: "Delivering data-driven recommendations that align with business objectives and support executive decision-making"
    }
  ];

  return (
    <section id="about" className="py-24 bg-gradient-to-b from-gray-950 to-black relative">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.01)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.01)_1px,transparent_1px)] bg-[size:100px_100px]"></div>
      
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <div className="inline-block px-4 py-2 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-full border border-blue-500/20 mb-6">
            <span className="text-blue-400 text-sm font-medium tracking-wider uppercase">About Me</span>
          </div>
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-8 tracking-tight">
            Data Analytics
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
              Expertise
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed">
            Specialized in transforming complex business data into strategic insights through advanced analytics methodologies
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center mb-24">
          <div className="space-y-8">
            <h3 className="text-4xl font-bold text-white leading-tight">
              Turning Data Into
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400"> Strategic Advantage</span>
            </h3>
            <div className="space-y-6 text-gray-300 text-lg leading-relaxed">
              <p>
                With over 5 years of specialized experience in data analytics, I help organizations unlock the hidden value 
                in their data through sophisticated statistical analysis and predictive modeling techniques.
              </p>
              <p>
                My expertise spans across multiple industries including finance, healthcare, retail, and technology, 
                where I've successfully delivered analytics solutions that have driven measurable business impact 
                and informed critical strategic decisions.
              </p>
              <p>
                I specialize in translating complex analytical findings into clear, actionable insights that 
                stakeholders can understand and implement, bridging the gap between data science and business strategy.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mt-10">
              {['Advanced Statistics', 'Predictive Modeling', 'Data Visualization', 'Business Intelligence', 'SQL & Python', 'Tableau & Power BI', 'Excel Analytics', 'Statistical Software'].map((tech, index) => (
                <div 
                  key={index}
                  className="px-4 py-3 bg-gradient-to-r from-gray-800/50 to-gray-700/50 text-gray-300 rounded-xl text-sm font-medium border border-gray-700/50 hover:border-gray-600/50 transition-all duration-200 backdrop-blur-sm"
                >
                  {tech}
                </div>
              ))}
            </div>
          </div>
          
          <div ref={skillsRef} className="relative">
            <div className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-3xl p-10 backdrop-blur-sm border border-gray-700/50">
              <div className="space-y-8">
                <div className="flex items-center justify-between">
                  <span className="text-gray-300 font-medium">Statistical Analysis</span>
                  <span className="text-blue-400 font-bold text-lg">{statisticalAnalysis}%</span>
                </div>
                <div className="w-full bg-gray-800/50 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-blue-400 h-3 rounded-full shadow-lg shadow-blue-500/25 transition-all duration-1000 ease-out" 
                    style={{width: `${statisticalAnalysis}%`}}
                  ></div>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-gray-300 font-medium">Data Visualization</span>
                  <span className="text-purple-400 font-bold text-lg">{dataVisualization}%</span>
                </div>
                <div className="w-full bg-gray-800/50 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-purple-500 to-purple-400 h-3 rounded-full shadow-lg shadow-purple-500/25 transition-all duration-1000 ease-out" 
                    style={{width: `${dataVisualization}%`}}
                  ></div>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-gray-300 font-medium">Predictive Analytics</span>
                  <span className="text-blue-400 font-bold text-lg">{predictiveAnalytics}%</span>
                </div>
                <div className="w-full bg-gray-800/50 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-blue-400 h-3 rounded-full shadow-lg shadow-blue-500/25 transition-all duration-1000 ease-out" 
                    style={{width: `${predictiveAnalytics}%`}}
                  ></div>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-gray-300 font-medium">Business Intelligence</span>
                  <span className="text-purple-400 font-bold text-lg">{businessIntelligence}%</span>
                </div>
                <div className="w-full bg-gray-800/50 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-purple-500 to-purple-400 h-3 rounded-full shadow-lg shadow-purple-500/25 transition-all duration-1000 ease-out" 
                    style={{width: `${businessIntelligence}%`}}
                  ></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skills.map((skill, index) => (
            <div 
              key={index}
              className="group bg-gradient-to-br from-gray-900/50 to-gray-800/50 rounded-2xl p-8 hover:from-gray-800/50 hover:to-gray-700/50 transition-all duration-500 transform hover:scale-105 border border-gray-700/50 hover:border-gray-600/50 backdrop-blur-sm relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <div className="relative z-10">
                <div className="flex items-center mb-6">
                  <div className="p-3 bg-gradient-to-br from-gray-800 to-gray-700 rounded-xl mr-4 group-hover:from-gray-700 group-hover:to-gray-600 transition-all duration-300">
                    {skill.icon}
                  </div>
                  <h3 className="text-xl font-bold text-white">{skill.title}</h3>
                </div>
                <p className="text-gray-300 leading-relaxed">{skill.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;