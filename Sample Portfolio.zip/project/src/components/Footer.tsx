import React from 'react';
import { Link } from 'react-router-dom';
import { BarChart3, Github, Linkedin, Youtube, Instagram, Facebook, Mail } from 'lucide-react';

const Footer = () => {
  const openEmailClient = () => {
    window.location.href = 'mailto:muhammadayanprivate@gmail.com';
  };

  const openLinkedIn = () => {
    window.open('https://linkedin.com/in/muhammadayan', '_blank', 'noopener,noreferrer');
  };

  const openGitHub = () => {
    window.open('https://github.com/muhammadayan', '_blank', 'noopener,noreferrer');
  };

  const openYouTube = () => {
    window.open('https://youtube.com/@muhammadayan', '_blank', 'noopener,noreferrer');
  };

  const openInstagram = () => {
    window.open('https://instagram.com/muhammadayan', '_blank', 'noopener,noreferrer');
  };

  const openFacebook = () => {
    window.open('https://facebook.com/muhammadayan', '_blank', 'noopener,noreferrer');
  };

  const openTikTok = () => {
    window.open('https://tiktok.com/@muhammadayan', '_blank', 'noopener,noreferrer');
  };

  return (
    <footer className="bg-black border-t border-gray-800/50 relative">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.01)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.01)_1px,transparent_1px)] bg-[size:100px_100px]"></div>
      
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16 relative z-10">
        <div className="grid md:grid-cols-4 gap-12">
          {/* Enhanced Brand */}
          <div className="md:col-span-2">
            <Link 
              to="/"
              className="flex items-center space-x-3 mb-6 hover:opacity-80 transition-opacity duration-200"
            >
              <div className="p-3 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl">
                <BarChart3 className="w-8 h-8 text-blue-400" />
              </div>
              <div>
                <h3 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                  Muhammad Ayan
                </h3>
                <p className="text-gray-400 text-sm font-medium tracking-wider">DATA ANALYTICS EXPERT</p>
              </div>
            </Link>
            <p className="text-gray-400 leading-relaxed mb-8 max-w-md">
              Transforming complex business data into strategic insights through advanced analytics methodologies. 
              Specialized in statistical analysis, predictive modeling, and data visualization.
            </p>
            <div className="flex space-x-3">
              <button
                onClick={openGitHub}
                className="w-12 h-12 bg-gradient-to-br from-gray-800/50 to-gray-700/50 rounded-xl flex items-center justify-center hover:from-gray-700/50 hover:to-gray-600/50 transition-all duration-300 border border-gray-700/50 hover:border-gray-600/50 group"
              >
                <Github className="w-5 h-5 text-gray-300 group-hover:text-white transition-colors duration-200" />
              </button>
              <button
                onClick={openLinkedIn}
                className="w-12 h-12 bg-gradient-to-br from-gray-800/50 to-gray-700/50 rounded-xl flex items-center justify-center hover:from-gray-700/50 hover:to-gray-600/50 transition-all duration-300 border border-gray-700/50 hover:border-gray-600/50 group"
              >
                <Linkedin className="w-5 h-5 text-gray-300 group-hover:text-white transition-colors duration-200" />
              </button>
              <button
                onClick={openYouTube}
                className="w-12 h-12 bg-gradient-to-br from-gray-800/50 to-gray-700/50 rounded-xl flex items-center justify-center hover:from-gray-700/50 hover:to-gray-600/50 transition-all duration-300 border border-gray-700/50 hover:border-gray-600/50 group"
              >
                <Youtube className="w-5 h-5 text-gray-300 group-hover:text-white transition-colors duration-200" />
              </button>
              <button
                onClick={openInstagram}
                className="w-12 h-12 bg-gradient-to-br from-gray-800/50 to-gray-700/50 rounded-xl flex items-center justify-center hover:from-gray-700/50 hover:to-gray-600/50 transition-all duration-300 border border-gray-700/50 hover:border-gray-600/50 group"
              >
                <Instagram className="w-5 h-5 text-gray-300 group-hover:text-white transition-colors duration-200" />
              </button>
              <button
                onClick={openFacebook}
                className="w-12 h-12 bg-gradient-to-br from-gray-800/50 to-gray-700/50 rounded-xl flex items-center justify-center hover:from-gray-700/50 hover:to-gray-600/50 transition-all duration-300 border border-gray-700/50 hover:border-gray-600/50 group"
              >
                <Facebook className="w-5 h-5 text-gray-300 group-hover:text-white transition-colors duration-200" />
              </button>
              <button
                onClick={openTikTok}
                className="w-12 h-12 bg-gradient-to-br from-gray-800/50 to-gray-700/50 rounded-xl flex items-center justify-center hover:from-gray-700/50 hover:to-gray-600/50 transition-all duration-300 border border-gray-700/50 hover:border-gray-600/50 group"
              >
                <svg className="w-5 h-5 text-gray-300 group-hover:text-white transition-colors duration-200" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
                </svg>
              </button>
              <button
                onClick={openEmailClient}
                className="w-12 h-12 bg-gradient-to-br from-gray-800/50 to-gray-700/50 rounded-xl flex items-center justify-center hover:from-gray-700/50 hover:to-gray-600/50 transition-all duration-300 border border-gray-700/50 hover:border-gray-600/50 group"
              >
                <Mail className="w-5 h-5 text-gray-300 group-hover:text-white transition-colors duration-200" />
              </button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-6 text-lg">Navigation</h4>
            <ul className="space-y-3">
              <li>
                <Link
                  to="/"
                  className="text-gray-400 hover:text-white transition-colors duration-200 hover:translate-x-1 transform"
                >
                  Home
                </Link>
              </li>
              <li>
                <Link
                  to="/about"
                  className="text-gray-400 hover:text-white transition-colors duration-200 hover:translate-x-1 transform"
                >
                  About
                </Link>
              </li>
              <li>
                <Link
                  to="/portfolio"
                  className="text-gray-400 hover:text-white transition-colors duration-200 hover:translate-x-1 transform"
                >
                  Portfolio
                </Link>
              </li>
              <li>
                <Link
                  to="/blog"
                  className="text-gray-400 hover:text-white transition-colors duration-200 hover:translate-x-1 transform"
                >
                  Blog
                </Link>
              </li>
              <li>
                <Link
                  to="/courses"
                  className="text-gray-400 hover:text-white transition-colors duration-200 hover:translate-x-1 transform"
                >
                  Courses
                </Link>
              </li>
              <li>
                <Link
                  to="/contact"
                  className="text-gray-400 hover:text-white transition-colors duration-200 hover:translate-x-1 transform"
                >
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Analytics Services */}
          <div>
            <h4 className="text-white font-semibold mb-6 text-lg">Analytics Services</h4>
            <ul className="space-y-3 text-gray-400">
              <li className="hover:text-gray-300 transition-colors duration-200">Statistical Analysis</li>
              <li className="hover:text-gray-300 transition-colors duration-200">Predictive Analytics</li>
              <li className="hover:text-gray-300 transition-colors duration-200">Data Visualization</li>
              <li className="hover:text-gray-300 transition-colors duration-200">Business Intelligence</li>
              <li className="hover:text-gray-300 transition-colors duration-200">Performance Analytics</li>
              <li className="hover:text-gray-300 transition-colors duration-200">Strategic Insights</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800/50 mt-16 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © 2024 Muhammad Ayan. All rights reserved.
          </p>
          <div className="flex items-center space-x-2 text-gray-400 text-sm mt-4 md:mt-0">
            <span>Built with precision and data-driven insights</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;