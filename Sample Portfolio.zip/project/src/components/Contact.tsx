import React from 'react';
import { Mail, Phone, MapPin, Send, Github, Linkedin, Twitter, MessageSquare, CheckCircle } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [isSubmitted, setIsSubmitted] = React.useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // In a real application, you would send this data to your backend
    console.log('Form submitted:', formData);
    
    setIsSubmitting(false);
    setIsSubmitted(true);
    
    // Reset form after 3 seconds
    setTimeout(() => {
      setFormData({ name: '', email: '', company: '', message: '' });
      setIsSubmitted(false);
    }, 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const openEmailClient = () => {
    window.location.href = 'mailto:muhammad.ayan@analytics.com?subject=Analytics Project Inquiry&body=Hi Muhammad, I would like to discuss a data analytics project...';
  };

  const makePhoneCall = () => {
    window.location.href = 'tel:+15551234567';
  };

  const openLinkedIn = () => {
    window.open('https://linkedin.com/in/muhammadayan', '_blank', 'noopener,noreferrer');
  };

  const openGitHub = () => {
    window.open('https://github.com/muhammadayan', '_blank', 'noopener,noreferrer');
  };

  const openTwitter = () => {
    window.open('https://twitter.com/muhammadayan', '_blank', 'noopener,noreferrer');
  };

  const openWhatsApp = () => {
    window.open('https://wa.me/15551234567?text=Hi Muhammad, I would like to discuss a data analytics project', '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contact" className="py-24 bg-gradient-to-b from-gray-950 to-black relative">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.01)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.01)_1px,transparent_1px)] bg-[size:100px_100px]"></div>
      
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <div className="inline-block px-4 py-2 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-full border border-blue-500/20 mb-6">
            <span className="text-blue-400 text-sm font-medium tracking-wider uppercase">Contact</span>
          </div>
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-8 tracking-tight">
            Let's Discuss Your
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
              Analytics Needs
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed">
            Ready to unlock the power of your data? Let's collaborate on your next analytics project
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Contact Info */}
          <div className="space-y-10">
            <div>
              <h3 className="text-3xl font-bold text-white mb-8">
                Transform Your Data Into Strategic Insights
              </h3>
              <p className="text-gray-300 text-lg leading-relaxed mb-8">
                I specialize in helping organizations make data-driven decisions through comprehensive analytics solutions. 
                Whether you need customer behavior analysis, financial modeling, or performance optimization, 
                I'm here to turn your data challenges into competitive advantages.
              </p>
            </div>

            <div className="space-y-6">
              <button 
                onClick={openEmailClient}
                className="flex items-center space-x-6 group w-full text-left"
              >
                <div className="flex-shrink-0 w-16 h-16 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-2xl flex items-center justify-center border border-blue-500/20 group-hover:border-blue-500/40 transition-all duration-300">
                  <Mail className="w-7 h-7 text-blue-400" />
                </div>
                <div>
                  <h4 className="text-white font-semibold text-lg mb-1 group-hover:text-blue-400 transition-colors duration-200">Email</h4>
                  <p className="text-gray-300 group-hover:text-white transition-colors duration-200">muhammad.ayan@analytics.com</p>
                </div>
              </button>

              <button 
                onClick={makePhoneCall}
                className="flex items-center space-x-6 group w-full text-left"
              >
                <div className="flex-shrink-0 w-16 h-16 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-2xl flex items-center justify-center border border-purple-500/20 group-hover:border-purple-500/40 transition-all duration-300">
                  <Phone className="w-7 h-7 text-purple-400" />
                </div>
                <div>
                  <h4 className="text-white font-semibold text-lg mb-1 group-hover:text-purple-400 transition-colors duration-200">Phone</h4>
                  <p className="text-gray-300 group-hover:text-white transition-colors duration-200">+1 (555) 123-4567</p>
                </div>
              </button>

              <div className="flex items-center space-x-6 group">
                <div className="flex-shrink-0 w-16 h-16 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-2xl flex items-center justify-center border border-blue-500/20 group-hover:border-blue-500/40 transition-all duration-300">
                  <MapPin className="w-7 h-7 text-blue-400" />
                </div>
                <div>
                  <h4 className="text-white font-semibold text-lg mb-1">Location</h4>
                  <p className="text-gray-300">San Francisco, CA</p>
                </div>
              </div>
            </div>

            {/* Professional Social Links */}
            <div className="pt-8">
              <h4 className="text-white font-semibold text-lg mb-6">Connect Professionally</h4>
              <div className="flex space-x-4">
                <button
                  onClick={openGitHub}
                  className="w-14 h-14 bg-gradient-to-br from-gray-800/50 to-gray-700/50 rounded-2xl flex items-center justify-center hover:from-gray-700/50 hover:to-gray-600/50 transition-all duration-300 border border-gray-700/50 hover:border-gray-600/50 group"
                >
                  <Github className="w-6 h-6 text-gray-300 group-hover:text-white transition-colors duration-200" />
                </button>
                <button
                  onClick={openLinkedIn}
                  className="w-14 h-14 bg-gradient-to-br from-gray-800/50 to-gray-700/50 rounded-2xl flex items-center justify-center hover:from-gray-700/50 hover:to-gray-600/50 transition-all duration-300 border border-gray-700/50 hover:border-gray-600/50 group"
                >
                  <Linkedin className="w-6 h-6 text-gray-300 group-hover:text-white transition-colors duration-200" />
                </button>
                <button
                  onClick={openTwitter}
                  className="w-14 h-14 bg-gradient-to-br from-gray-800/50 to-gray-700/50 rounded-2xl flex items-center justify-center hover:from-gray-700/50 hover:to-gray-600/50 transition-all duration-300 border border-gray-700/50 hover:border-gray-600/50 group"
                >
                  <Twitter className="w-6 h-6 text-gray-300 group-hover:text-white transition-colors duration-200" />
                </button>
                <button
                  onClick={openWhatsApp}
                  className="w-14 h-14 bg-gradient-to-br from-gray-800/50 to-gray-700/50 rounded-2xl flex items-center justify-center hover:from-gray-700/50 hover:to-gray-600/50 transition-all duration-300 border border-gray-700/50 hover:border-gray-600/50 group"
                >
                  <MessageSquare className="w-6 h-6 text-gray-300 group-hover:text-white transition-colors duration-200" />
                </button>
              </div>
            </div>
          </div>

          {/* Enhanced Contact Form */}
          <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/50 rounded-3xl p-10 border border-gray-700/50 backdrop-blur-sm relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5"></div>
            <div className="relative z-10">
              {isSubmitted ? (
                <div className="text-center py-12">
                  <div className="w-20 h-20 bg-gradient-to-br from-green-500/20 to-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle className="w-10 h-10 text-green-400" />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-4">Message Sent Successfully!</h3>
                  <p className="text-gray-300">Thank you for reaching out. I'll get back to you within 24 hours.</p>
                </div>
              ) : (
                <>
                  <div className="flex items-center space-x-3 mb-8">
                    <div className="p-3 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl">
                      <Send className="w-6 h-6 text-blue-400" />
                    </div>
                    <h3 className="text-2xl font-bold text-white">Start a Conversation</h3>
                  </div>
                  
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <label htmlFor="name" className="block text-white font-semibold mb-3">
                          Full Name *
                        </label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          value={formData.name}
                          onChange={handleChange}
                          required
                          className="w-full px-5 py-4 bg-gray-800/50 border border-gray-600/50 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all duration-300 backdrop-blur-sm"
                          placeholder="Your full name"
                        />
                      </div>

                      <div>
                        <label htmlFor="company" className="block text-white font-semibold mb-3">
                          Company
                        </label>
                        <input
                          type="text"
                          id="company"
                          name="company"
                          value={formData.company}
                          onChange={handleChange}
                          className="w-full px-5 py-4 bg-gray-800/50 border border-gray-600/50 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all duration-300 backdrop-blur-sm"
                          placeholder="Your company"
                        />
                      </div>
                    </div>

                    <div>
                      <label htmlFor="email" className="block text-white font-semibold mb-3">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full px-5 py-4 bg-gray-800/50 border border-gray-600/50 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all duration-300 backdrop-blur-sm"
                        placeholder="your.email@company.com"
                      />
                    </div>

                    <div>
                      <label htmlFor="message" className="block text-white font-semibold mb-3">
                        Project Details *
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        required
                        rows={6}
                        className="w-full px-5 py-4 bg-gray-800/50 border border-gray-600/50 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all duration-300 resize-none backdrop-blur-sm"
                        placeholder="Tell me about your analytics needs, data challenges, or project requirements..."
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-xl font-semibold hover:from-blue-600 hover:to-purple-600 transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-3 shadow-lg hover:shadow-blue-500/25 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                          <span>Sending...</span>
                        </>
                      ) : (
                        <>
                          <Send className="w-5 h-5" />
                          <span>Send Message</span>
                        </>
                      )}
                    </button>
                  </form>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;