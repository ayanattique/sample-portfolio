import React from 'react';
import { Star, Quote, User, Building, Calendar } from 'lucide-react';

const ClientReviews = () => {
  const reviews = [
    {
      name: "Sarah Johnson",
      position: "VP of Analytics",
      company: "TechCorp Solutions",
      image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150",
      rating: 5,
      review: "Muhammad's expertise in data analytics transformed our business intelligence capabilities. His predictive models increased our sales forecast accuracy by 35%, directly impacting our bottom line. Exceptional work!",
      project: "Sales Performance Analytics",
      date: "December 2023"
    },
    {
      name: "David Chen",
      position: "Chief Financial Officer",
      company: "InvestPro Capital",
      image: "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150",
      rating: 5,
      review: "The financial risk assessment model Muhammad developed for our portfolio management was outstanding. We reduced our risk exposure by 18% while maintaining strong returns. His analytical skills are top-notch.",
      project: "Financial Risk Modeling",
      date: "November 2023"
    },
    {
      name: "Emily Rodriguez",
      position: "Marketing Director",
      company: "RetailMax Inc",
      image: "https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=150",
      rating: 5,
      review: "Muhammad's customer behavior analysis revolutionized our marketing strategy. The segmentation models he created helped us improve customer retention by 23%. His insights are invaluable for data-driven decision making.",
      project: "Customer Analytics Dashboard",
      date: "October 2023"
    },
    {
      name: "Dr. Michael Thompson",
      position: "Research Director",
      company: "HealthCare Analytics",
      image: "https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=150",
      rating: 5,
      review: "Working with Muhammad on our healthcare outcomes analysis was exceptional. His statistical expertise helped us identify factors that improved patient outcomes by 28%. Professional, thorough, and results-driven.",
      project: "Healthcare Outcomes Analysis",
      date: "September 2023"
    },
    {
      name: "Lisa Wang",
      position: "Operations Manager",
      company: "LogiFlow Systems",
      image: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150",
      rating: 5,
      review: "Muhammad's inventory optimization solution was a game-changer for our operations. We reduced inventory costs by 22% while maintaining service levels. His analytical approach and attention to detail are remarkable.",
      project: "Retail Inventory Optimization",
      date: "August 2023"
    },
    {
      name: "James Mitchell",
      position: "Digital Marketing Lead",
      company: "GrowthHack Agency",
      image: "https://images.pexels.com/photos/1212984/pexels-photo-1212984.jpeg?auto=compress&cs=tinysrgb&w=150",
      rating: 5,
      review: "The marketing campaign performance analysis Muhammad delivered exceeded our expectations. His attribution modeling helped us improve campaign ROI by 31%. Clear communication and actionable insights throughout the project.",
      project: "Marketing Campaign Analysis",
      date: "July 2023"
    }
  ];

  const [currentReview, setCurrentReview] = React.useState(0);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setCurrentReview((prev) => (prev + 1) % reviews.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [reviews.length]);

  const nextReview = () => {
    setCurrentReview((prev) => (prev + 1) % reviews.length);
  };

  const prevReview = () => {
    setCurrentReview((prev) => (prev - 1 + reviews.length) % reviews.length);
  };

  const goToReview = (index: number) => {
    setCurrentReview(index);
  };

  return (
    <section className="py-24 bg-gradient-to-b from-gray-950 to-black relative">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.01)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.01)_1px,transparent_1px)] bg-[size:100px_100px]"></div>
      
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <div className="inline-block px-4 py-2 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-full border border-blue-500/20 mb-6">
            <span className="text-blue-400 text-sm font-medium tracking-wider uppercase">Client Reviews</span>
          </div>
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-8 tracking-tight">
            What Clients
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
              Say About Me
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed">
            Trusted by industry leaders for delivering exceptional analytics solutions that drive real business results
          </p>
        </div>

        {/* Featured Review */}
        <div className="max-w-4xl mx-auto mb-16">
          <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/50 rounded-3xl p-12 backdrop-blur-sm border border-gray-700/50 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5"></div>
            
            <div className="relative z-10">
              <div className="flex items-center justify-center mb-8">
                <Quote className="w-12 h-12 text-blue-400/50" />
              </div>
              
              <div className="text-center mb-8">
                <div className="flex justify-center mb-4">
                  {[...Array(reviews[currentReview].rating)].map((_, i) => (
                    <Star key={i} className="w-6 h-6 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-xl md:text-2xl text-gray-300 leading-relaxed italic">
                  "{reviews[currentReview].review}"
                </p>
              </div>
              
              <div className="flex items-center justify-center space-x-6">
                <img 
                  src={reviews[currentReview].image} 
                  alt={reviews[currentReview].name}
                  className="w-16 h-16 rounded-full object-cover border-2 border-blue-500/30"
                />
                <div className="text-center">
                  <h4 className="text-white font-bold text-lg">{reviews[currentReview].name}</h4>
                  <p className="text-blue-400 font-medium">{reviews[currentReview].position}</p>
                  <p className="text-gray-400">{reviews[currentReview].company}</p>
                </div>
              </div>
              
              <div className="flex items-center justify-center space-x-6 mt-6 text-gray-400 text-sm">
                <div className="flex items-center space-x-2">
                  <Building className="w-4 h-4" />
                  <span>{reviews[currentReview].project}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4" />
                  <span>{reviews[currentReview].date}</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Navigation */}
          <div className="flex items-center justify-center space-x-4 mt-8">
            <button
              onClick={prevReview}
              className="w-12 h-12 bg-gray-800/50 rounded-full flex items-center justify-center hover:bg-gray-700/50 transition-colors duration-200 border border-gray-700/50"
            >
              <svg className="w-5 h-5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            
            <div className="flex space-x-2">
              {reviews.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToReview(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-200 ${
                    index === currentReview 
                      ? 'bg-blue-400 w-8' 
                      : 'bg-gray-600 hover:bg-gray-500'
                  }`}
                />
              ))}
            </div>
            
            <button
              onClick={nextReview}
              className="w-12 h-12 bg-gray-800/50 rounded-full flex items-center justify-center hover:bg-gray-700/50 transition-colors duration-200 border border-gray-700/50"
            >
              <svg className="w-5 h-5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>

        {/* All Reviews Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <div 
              key={index}
              className={`group bg-gradient-to-br from-gray-900/50 to-gray-800/50 rounded-2xl p-8 hover:from-gray-800/50 hover:to-gray-700/50 transition-all duration-500 transform hover:scale-105 border border-gray-700/50 hover:border-gray-600/50 backdrop-blur-sm relative overflow-hidden ${
                index === currentReview ? 'ring-2 ring-blue-500/50' : ''
              }`}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              
              <div className="relative z-10">
                <div className="flex justify-center mb-4">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                  ))}
                </div>
                
                <p className="text-gray-300 mb-6 leading-relaxed text-sm italic">
                  "{review.review.length > 120 ? review.review.substring(0, 120) + '...' : review.review}"
                </p>
                
                <div className="flex items-center space-x-4">
                  <img 
                    src={review.image} 
                    alt={review.name}
                    className="w-12 h-12 rounded-full object-cover border-2 border-blue-500/30"
                  />
                  <div>
                    <h4 className="text-white font-bold">{review.name}</h4>
                    <p className="text-blue-400 text-sm">{review.position}</p>
                    <p className="text-gray-400 text-xs">{review.company}</p>
                  </div>
                </div>
                
                <div className="mt-4 pt-4 border-t border-gray-700/50">
                  <p className="text-gray-400 text-xs">{review.project}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ClientReviews;